from PIL import image, imageFilter

before = imapge. open("bridge.bmp")
after = before.filter(imagefilter.Boxblur(1))
after.save("out.bmp")
