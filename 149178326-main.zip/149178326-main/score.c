#include<stdio.h>
#include<cs50.h>

int main (void)

{
    int score [3];

score[0] = get_int("score 1: ");
score[1] = get_int("score 2: ");
score[2] = get_int("score 3: ");

printf("Avarage : %f\n" , (score[0] + score[2] + score[1]) / 3.0 );

}
