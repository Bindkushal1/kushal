#include <stdio.h>

// Define the structure
struct personal {
    char name[50];
    char date_of_joining[20];
    float salary;
};

int main() {
    // Declare variables
    struct personal people[5];

    // Read information for 5 people
    for (int i = 0; i < 5; i++) {
        printf("Enter name for person %d: ", i + 1);
        scanf(" %[^\n]", people[i].name);  // Read until newline character
        printf("Enter date of joining for person %d (DD/MM/YYYY): ", i + 1);
        scanf(" %[^\n]", people[i].date_of_joining);  // Read until newline character
        printf("Enter salary for person %d: ", i + 1);
        scanf("%f", &people[i].salary);
    }

    // Print information for 5 people
    printf("\nInformation for 5 people:\n");
    for (int i = 0; i < 5; i++) {
        printf("Person %d\n", i + 1);
        printf("Name: %s\n", people[i].name);
        printf("Date of joining: %s\n", people[i].date_of_joining);
        printf("Salary: %.2f\n", people[i].salary);
    }

    return 0;
}
