#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Function prototypes
void printBoard(char *board);
void printRules();
int checkForWin(char *board);
bool makeMove(char *board, char player, int position);

int main() {
    // Initialize variables
    char board[9] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
    char player1[50], player2[50];
    char currentPlayer, winner;
    int choice;
    bool gameover = false;

    // Print rules
    printRules();

    // Get player names
    printf("\nEnter name of Player 1: ");
    scanf("%s", player1);
    printf("Enter name of Player 2: ");
    scanf("%s", player2);

    // Decide X or O for players
    printf("\n%s, choose X or O: ", player1);
    scanf(" %c", &currentPlayer);
    char opponentPlayer = (currentPlayer == 'X' || currentPlayer == 'x') ? 'O' : 'X';

    // Game loop
    while (!gameover) {
        // Print board
        printf("\n\n");
        printBoard(board);

        // Get current player's move
        printf("%c, type any digit from 1-9 to fill your response: ", currentPlayer);
        scanf("%d", &choice);

        // Make move and check for win
        if (makeMove(board, currentPlayer, choice)) {
            winner = checkForWin(board);
            if (winner != ' ') {
                gameover = true;
            } else {
                // Switch player
                currentPlayer = (currentPlayer == 'X' || currentPlayer == 'x') ? 'O' : 'X';
            }
        } else {
            printf("Wrong Selection\n");
        }
    }

    // Print final board
    printf("\n\n");
    printBoard(board);

    // Print winner or draw
    if (winner == currentPlayer) {
        printf("\n\n%s Wins!\n\n", (currentPlayer == 'X' || currentPlayer == 'x') ? player1 : player2);
    } else {
        printf("\n\nGame Draws!\n\n");
    }

    return 0;
}

// Function to print the board
void printBoard(char *board) {
    printf("\tTic-Tac-Toe\n\n");
    printf("  %c | %c | %c\n", board[0], board[1], board[2]);
    printf(" -----------\n");
    printf("  %c | %c | %c\n", board[3], board[4], board[5]);
    printf(" -----------\n");
    printf("  %c | %c | %c\n", board[6], board[7], board[8]);
}

// Function to print rules
void printRules() {
    printf("\tTic-Tac-Toe\n\n");
    printf("Welcome to the most played 2D game and a sort of fun using X and O\n\n");
    printf("Rules:-\n");
    printf("1: Each player will be entering the number to put respective X or O in the desired position\n");
    printf("2: Player who gets a combination of 3 same characters either diagonal or horizontally or vertically will be declared as the winner\n");
    printf("\nEnjoy the game! Be a Winner!\n\n");
}

// Function to check for a win
int checkForWin(char *board) {
    // Check rows
    for (int i = 0; i < 9; i += 3) {
        if (board[i] == board[i + 1] && board[i + 1] == board[i + 2]) {
            return board[i];
        }
    }

    // Check columns
    for (int i = 0; i < 3; i++) {
        if (board[i] == board[i + 3] && board[i + 3] == board[i + 6]) {
            return board[i];
        }
    }

    // Check diagonals
    if ((board[0] == board[4] && board[4] == board[8]) || (board[2] == board[4] && board[4] == board[6])) {
        return board[4];
    }

    // Check for draw
    for (int i = 0; i < 9; i++) {
        if (board[i] != 'X' && board[i] != 'O') {
            return ' ';
        }
    }

    return '-';
}

// Function to make a move
bool makeMove(char *board, char player, int position) {
    if (position < 1 || position > 9 || board[position - 1] == 'X' || board[position - 1] == 'O') {
        return false;
    }
    board[position - 1] = player;
    return true;
}
