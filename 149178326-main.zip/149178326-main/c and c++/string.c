#include <stdio.h>

// Function to find the length of the string through pointers
int string_length(char* given_string)
{
	// Variable to store the length of the string
	int length = 0;
	while (*given_string != '\0') {
		length++;
		given_string++;
	}
	return length;
}

// Driver function
int main()
{
	// Array to store the string
	char given_string[] = "GeeksforGeeks";
	printf("Length of the String: %d", string_length(given_string));
	return 0;
}
