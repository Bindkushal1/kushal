#include <stdio.h>

int main() {
    char operator;
    double num1, num2, result;

    // Prompt the user to enter the first number
    printf("Enter the first number: ");
    scanf("%lf", &num1);

    // Prompt the user to enter the operator
    printf("Enter operator (+, -, *, /): ");
    scanf(" %c", &operator);

    // Prompt the user to enter the second number
    printf("Enter the second number: ");
    scanf("%lf", &num2);

    // Perform operation based on operator
    switch (operator) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            if (num2 != 0) {
                result = num1 / num2;
            } else {
                printf("Error! Division by zero is not allowed.\n");
                return 1; // Exit with error code
            }
            break;
        default:
            printf("Error! Invalid operator.\n");
            return 1; // Exit with error code
    }

    // Display the result
    printf("Result: %.2f\n", result);

    return 0;
}
