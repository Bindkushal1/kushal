#include <stdio.h>

int binomialCoeff(int n, int k) {
    int res = 1;
    if (k > n - k)
        k = n - k;
    for (int i = 0; i < k; ++i) {
        res *= (n - i);
        res /= (i + 1);
    }
    return res;
}

void printPascalTriangle(int n) {
    for (int line = 0; line < n; ++line) {
        for (int i = 0; i < n - line - 1; ++i)
            printf("  "); // Adding leading spaces
        for (int i = 0; i <= line; ++i)
            printf("%4d", binomialCoeff(line, i)); // Adjust spacing for wider numbers
        printf("\n");
    }
}

int main() {
    int rows;
    printf("Enter the number of rows for Pascal's Triangle: ");
    scanf("%d", &rows);
    printf("Pascal's Triangle with %d rows:\n", rows);
    printPascalTriangle(rows);
    return 0;
}
