#include <stdio.h>

int main() {
    int r1, c1, r2, c2;

    printf("Enter the number of rows of the first matrix: ");
    scanf("%d", &r1);

    printf("Enter the number of columns of the first matrix: ");
    scanf("%d", &c1);

    printf("Enter the number of rows of the second matrix: ");
    scanf("%d", &r2);

    printf("Enter the number of columns of the second matrix: ");
    scanf("%d", &c2);

    if (r1 != r2 || c1 != c2) {
        printf("Matrix addition is not possible.\n");
        return 0;
    }

    int a[100][100], b[100][100], sum[100][100], i, j;

    printf("\nEnter the elements of the first matrix:\n");
    for (i = 0; i < r1; i++) {
        for (j = 0; j < c1; j++) {
            printf("Enter the element a%d %d: ", i + 1, j + 1);
            scanf("%d", &a[i][j]);
        }
    }

    printf("\nEnter the elements of the second matrix:\n");
    for (i = 0; i < r2; i++) {
        for (j = 0; j < c2; j++) {
            printf("Enter the element b%d %d: ", i + 1, j + 1);
            scanf("%d", &b[i][j]);
        }
    }

    return 0;
}
