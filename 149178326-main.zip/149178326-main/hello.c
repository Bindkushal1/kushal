#include <cs50.h>
#include <stdio.h>

int main (void)
{

string que = get_string(" whats your name ? :");
printf("hello , %s\n" , que);
}
