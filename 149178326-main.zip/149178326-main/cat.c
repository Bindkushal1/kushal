
# Replace the API key with your own API key.
API_KEY = "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"

# The text you want to convert into an image.
text = "Hello, world!"

# The URL of the API endpoint.
url = "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"

# The request headers.
headers = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {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}"
}

# The request body.
body = {
    "text": text
}

# Make the API call.
response = requests.post(url, headers=headers, json=body)

# Check the response status code.
if response.status_code != 200:
    raise Exception("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")

# Get the image data from the response.
image_data = response.json()["image_data"]

# Save the image data to a file.
with open("image.png", "wb") as f:
    f.write(image_data)
