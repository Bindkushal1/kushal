#include <stdio.h>

int main() {
    int rows;
    printf("Enter the number of rows for Pascal's Triangle: ");
    scanf("%d", &rows);

    // Pascal's Triangle 2D array initialization
    int triangle[rows][rows];

    // Populate the triangle
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j <= i; j++) {
            if (j == 0 || j == i) // First and last elements in each row are 1
                triangle[i][j] = 1;
            else // Other elements are sum of above two elements from the previous row
                triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
        }
    }

    // Print Pascal's Triangle in pyramid shape
    for (int i = 0; i < rows; i++) {
        // Print leading spaces for pyramid shape
        for (int j = 0; j < rows - i - 1; j++)
            printf("  ");
        // Print elements of the current row
        for (int j = 0; j <= i; j++)
            printf("%4d ", triangle[i][j]);
        printf("\n");
    }

    return 0;
}
