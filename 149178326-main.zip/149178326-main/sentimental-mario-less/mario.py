from cs50 import get_int

def main():
    while True:
        height = get_int("Height: ")

        if height > 0 and height < 9:
            break
        else:
            if height <= 0:
                print("Height must be a positive integer.")
            else:
                print("Height must be less than 9.")

    for i in range(1, height + 1):
        spaces = " " * (height - i)
        hashes = "#" * i
        print(spaces + hashes)

if __name__ == "__main__":
    main()
