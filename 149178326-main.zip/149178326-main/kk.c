#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int quarters, dimes, nickels, pennies, coins = 0;
    int cents;

    do
    {
        cents = get_int("Change owed: ");
    }
    while (cents < 0);

    quarters = cents / 25;
    cents = cents % 25;

    dimes = cents / 10;
    cents = cents % 10;

    nickels = cents / 5;
    cents = cents % 5;

    pennies = cents;

    coins = quarters + dimes + nickels + pennies;

    printf("%d\n", coins);

    return 0;
}
