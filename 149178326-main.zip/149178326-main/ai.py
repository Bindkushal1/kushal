import os
import requests

# Set your OpenAI API key
api_key = "AIzaSyDBXWLABHtkdbIuvayiWlZR1BpMF0Dssn0"  # Replace "gemini-api-key" with your actual Gemini API key

# Set the image generation parameters
prompt = "A cute cat"
image_size = "256x256"

# Make the request to the OpenAI API
response = requests.post(
    "https://api.openai.com/v1/images",
    headers={"Authorization": f"Bearer {api_key}"},
    json={"prompt": prompt, "image_size": image_size},
)

# Check if the request was successful
if response.status_code == 200:
    # Save the generated image to a file
    with open("cat.png", "wb") as f:
        f.write(response.content)
    print("Image generated successfully!")
else:
    print("Failed to generate image. Status code:", response.status_code)
    print("Response:", response.text)
