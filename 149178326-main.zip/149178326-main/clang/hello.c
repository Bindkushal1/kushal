#include <stdio.h>

int main(void)
{
    printf("What's your name? ");
    char answer[100];
    fgets(answer, sizeof(answer), stdin);
    printf("hello, %s\n", answer);
    return 0;
}
