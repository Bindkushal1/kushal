
#include <stdio.h>

int main (void)

{
    for (int i = 0; i < 5; i++)
{
        printf("hello world\n");
        printf("i is %i\n" , i);
    }


}
